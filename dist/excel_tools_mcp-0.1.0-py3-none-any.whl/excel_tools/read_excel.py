"""按范围读取Excel数据。"""

from excel_tools.exceptions import SheetNotFoundError
from excel_tools.core_utils import open_workbook, resolve_excel_file_path
from excel_tools.mcp_instance import excel_mcp

def _normalize_range(start_cell: str, end_cell: str | None) -> tuple[str, str]:
    """规范化范围参数。"""
    # 支持把A1:B2放在start_cell里
    if ":" in start_cell and end_cell is None:
        parts = start_cell.split(":")
        return parts[0], parts[1]
    return start_cell, (end_cell or start_cell)


@excel_mcp.tool()
async def excel_read_range(
    sheet: str,
    file_path: str = "",
    start_cell: str = "A1",
    end_cell: str | None = None,
) -> dict[str, object]:
    """读取指定工作表中的矩形区域。"""
    async with resolve_excel_file_path(file_path=file_path) as path:
        norm_start, norm_end = _normalize_range(start_cell, end_cell)
        # 打开工作簿。
        workbook = open_workbook(path, read_only=False, data_only=False)
        try:
            # 检查sheet存在性。
            if sheet not in workbook.sheetnames:
                raise SheetNotFoundError(
                    message=f"表单 '{sheet}' 未找到。",
                    suggested_action=f"可用表单: {workbook.sheetnames}",
                    details={"requested_sheet": sheet, "available_sheets": workbook.sheetnames},
                )

            # 获取工作表对象。
            worksheet = workbook[sheet]
            # 获取矩形区域单元格二维元组。
            rows = worksheet[norm_start:norm_end]
            # 转换为列表结果。
            values: list[list[object]] = []
            # 遍历每一行。
            for row_cells in rows:
                # 当前行值列表。
                row_values: list[object] = []
                # 逐列提取值。
                for cell in row_cells:
                    row_values.append(cell.value)
                # 追加到结果集。
                values.append(row_values)

            return {
                "sheet": sheet,
                "range": f"{norm_start}:{norm_end}",
                "rows": len(values),
                "cols": len(values[0]) if values else 0,
                "data": values,
                "resolved_file_path": str(path),
            }
        finally:
            workbook.close()
