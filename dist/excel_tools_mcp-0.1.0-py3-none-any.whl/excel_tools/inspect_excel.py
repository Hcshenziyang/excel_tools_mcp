# -*- coding:utf-8 -*-
"""
Excel 文件检查工具
"""

# 工具介绍：只读取excel文件元信息，不触碰cell内容。
from excel_tools.mcp_instance import excel_mcp
from excel_tools.core_utils import open_workbook, resolve_excel_file_path
from pydantic import BaseModel, Field
from openpyxl.utils import range_boundaries
import os

FORMULA_SCAN_ROWS = os.getenv("FORMULA_SCAN_ROWS", 1000)
FORMULA_SCAN_COLS = os.getenv("FORMULA_SCAN_COLS", 1000)


class SheetInfo(BaseModel):
    name: str = Field(..., description="Sheet名称，在workbook中显示的名称。")
    rows: int | None = Field(...,description="包含内容的行数。如果workbook没有声明维度，并且检测失败，则可能为None。",)
    cols: int | None = Field(...,description="包含内容的列数。如果workbook没有声明维度，并且检测失败，则可能为None。",)
    dimension_source: str = Field(...,description="行/列的确定方式：'declared' (从xlsx维度标签确定)，'calculated' (从calculate_dimension确定)，或'unknown'。")

class InspectResult(BaseModel):
    file_path: str  # 文件路径
    file_size_bytes: int  # 文件大小
    sheet_count: int  # 表单数量
    sheets: list[SheetInfo]  # 每个表单的详细信息

def _parse_dimension(dim: str) -> tuple[int, int]:
    """解析xlsx维度字符串，如'A1:O247'，返回(行数, 列数)。
    返回(0, 0)，如果表单为空('A1:A1'没有内容)。
    """
    # 将范围字符串转换为边界元组:单元格坐标将被转换为包含两个端点的范围
    # 示例: 'A1:O247' -> (1, 1, 16, 247)
    _, _, max_col, max_row = range_boundaries(dim)
    rows = max_row if max_row else 0
    cols = max_col if max_col else 0
    return rows, cols

def _get_sheet_dimensions(ws) -> tuple[int | None, int | None, str]:
    """确定表单的行/列数，并提供回退。
    返回(rows, cols, source)，其中source ∈ {'declared', 'calculated', 'unknown'}。

    在只读模式下，max_row/max_column来自xlsx维度标签，可能缺失或过时。我们回退到calculate_dimension()，
    虽然需要扫描，但仍然比读取值便宜。
    """
    # 首先尝试声明的维度(便宜)
    try:
        return ws.max_row, ws.max_column, "declared"
    except Exception:
        pass

    # 回退到calculate_dimension
    try:
        dim = ws.calculate_dimension()
        rows, cols = _parse_dimension(dim) # 解析维度字符串，返回(行数, 列数)
        return rows, cols, "calculated"
    except Exception:
        return None, None, "unknown" # 如果计算维度失败，返回None

@excel_mcp.tool()
async def excel_inspect(file_path: str = "") -> dict[str, object]:
    async with resolve_excel_file_path(file_path=file_path) as path:
        file_size = path.stat().st_size  # 获取文件大小
        wb = open_workbook(  # 打开工作簿
            path,
            read_only=False,
            data_only=False
            )
        try:
            sheet_infos: list[SheetInfo] = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows, cols, dim_source = _get_sheet_dimensions(ws)  # 确定表单的行/列数，并提供回退
                sheet_infos.append(
                    SheetInfo(
                        name=sheet_name,
                        rows=rows,
                        cols=cols,
                        dimension_source=dim_source,
                        )
                    )
            result = InspectResult(
                file_path=str(path),
                file_size_bytes=file_size,
                sheet_count=len(sheet_infos),
                sheets=sheet_infos,
            )
            return result.model_dump()
        finally:
            wb.close()
